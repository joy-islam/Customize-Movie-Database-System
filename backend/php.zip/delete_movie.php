<?php
        include("connect.php");
$user_email = $_GET['email'];

$delete_movie = "delete from watchlist where User_Email = '$user_email' ";

$query = mysqli_query($conn,$delete_movie );
if ($query) {
  header('Location:'.'watchlist.php');
}
else {
  echo "Something went Wrong!!!";
}
 ?>
