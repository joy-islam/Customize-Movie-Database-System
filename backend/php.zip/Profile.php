<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./profile.css">
    <title>Profile</title>
  </head>
  <body>
    <div>
<h1>ProFile</h1>
<br>
<a href="#">Search</a>
<h2>Massive Cinema</h2>

Profile Picture:
<br>
Name:
<br>
WISHLIST
<br>
WATCHLIST
<br>
<br>
<br>
<br>
<br>
Favourite Movies:
<br>

</p>
<br>
<a href="#"class="nav-link">Home</a>
<br>
<a href="#"c class="nav-link">Logout</a>


    </div>
  </body>
</html>
