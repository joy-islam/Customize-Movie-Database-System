<?php
include("connect.php");
$Movie_id= $_GET['id'];
$movie_query="select * from movie where ID='$Movie_id'";
$sql=mysqli_query($conn,$movie_query);
$row=mysqli_fetch_assoc($sql);

?>

<form action="./movie_update.php?ID=<?$row ['id']; ?>" method="post">
Movie Name: <input type="text" name="Moviename" value="<?=$row ['Name'] ?>">
<br>
Release Date: <input type="date" name="Date" value="<?=$row ['Release_date'] ?>">
<br>
Duration: <input type="hour" name="duration" value="<?=$row ['Duration']?>">
<br>
Language: <input type="text" name="language" value="<?=$row ['Language']  ?>">
<br>
Trailer:<input type="url" name="trailer" value="<?= $row ['Trailer']?>">
<br>
Description: <input type="text" name="description" value="<?=$row['Description'] ?>">
<br>
Genre: <input type="text" name="genre" value="<?=$row ['Genre'] ?>">
<br>
<input type="submit" name="update" value="update">










</form>
