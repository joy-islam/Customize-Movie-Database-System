<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">

    <title>Sign Up</title>
  </head>
  <body>
<center>
  <div>
<h1>Sign Up</h1>
<h2>Join Massive Cinema</h2>
<br>
<br>
<form action="./signup.php" method="post">


<input type="text" name="Email" placeholder="E-Mail">
<br>
<br>

<input type="text" name="name" placeholder="User-Name">
<br>
<br>

<input type="password" name="password" placeholder="Password">
<br>
<br>
<input type="text" name="Phone-Number" placeholder="Phone-Number">
<br>
<br>
<a href="https://www.bkash.com/" class="nav-link" target="_blank">CLick here to Payment</a>
<br>
<input type="text" name="tid" placeholder="Transction-ID">
<br>
<br>

<input type="checkbox" name="Terms and Conditions" value="term"> <font-color="white">I am atleast 16 years old and accept the terms.</font>
<br>
<br>

<input type="submit" name="registration" value="registration">
</form>
<a href="./movie.php">Home Page</a>
  </div>
</center>
  </body>
</html>
